#include <pthread.h>
#include <semaphore.h>
#include "MapReduceFramework.h"
#include <fstream>
#include <sys/time.h>
#include <iostream>
#include <map>
#include <iomanip>
#include <zconf.h>
#include <algorithm>

using namespace std;

#define CHUNK 10
#define INITIALIZE 0
#define DATE "%d.%m.%Y %l:%M:%S"
#define SUCCESS 0
#define FAILURE -1
#define NANOSECONDS " ns"
#define NANOSECOND_CONVERSION 1000000
#define MapReduceLog "/.MapReduceFramework.log"
#define MAPREDUCEINITIALIZE "RunMapReduceFramework started with "
#define THREADS " threads"
#define MAPREDUCEFAIL "MapReduceFramework Failure: "
#define FAIL " failed."
#define CREATE_THREAD "pthread_create"
#define MUTEX_INIT "pthread_mutex_init"
#define MUTEX_LOCK "pthread_mutex_lock"
#define MUTEX_UNlOCK "pthread_mutex_unlock"
#define MUTEX_DESTROY "pthread_mutex_destroy"
#define SEM_DESTROY "sem_destroy"
#define SEM_INIT "sem_init"
#define MAP_REDUCE_COMPLETE "RunMapReduceFramework finished"
#define SEM_POST "sem_post"
#define GETCWD "getcwd"
#define FREOPEN "freopen"
#define MAP_SHUFFLE_TIME "Map and Shuffle took "
#define REDUCE_TIME "Reduce took "
#define DUP "dup2"
#define CLOSE "close_file"
#define MAX_BUF 64
#define JOIN "pthread_join"
#define SHUFFLE_TERMINATED "Thread Shuffle terminated"
#define EXECMAP_TERMINATED "Thread ExecMap terminated"
#define EXECMAP_CREATED "Thread ExecMap created"
#define SHUFFLE_CREATED "Thread Shuffle created"
#define REDUCE_MAP_TERMINATED "Thread ReduceMap terminated"
#define REDUCE_MAP_CREATED "Thread ReduceMap created"


inline void errorOutput (string functionName)
{
	cerr << MAPREDUCEFAIL << functionName << FAIL << endl;
	exit(SUCCESS);
}
struct emitCompartor
{
    bool operator() (const pair<k3Base*, v3Base*> pair1, const pair<k3Base*, v3Base*> pair2) const
    {
        return *(pair1.first) < *(pair2.first);
    }
} emitCompartor;

bool autoDelete;
unsigned long chunkPointer;
unsigned long chunkPointerMap;
unsigned int mapThreadCounter;
time_t now;
sem_t sem;
MapReduceBase *mapReduceglobal;
IN_ITEMS_VEC global_item_vec;
map<pthread_t, vector<pair<k2Base*, v2Base*>>> pthreadsToContainer;
map<pthread_t, pthread_mutex_t> pthreadsToMutex;
map<k2Base*, V2_VEC, bool (*)(k2Base*,k2Base*)> shuffleContainers;
OUT_ITEMS_VEC emit3Container;
pthread_mutex_t mut, mut_container, mut_container_reduce, pthreadToContainerMutex, emit3Mutex,
		log_mut, tCountMut, globalMut;

void buildlog(string msg)
{
    time(&now);
	if (pthread_mutex_lock(&log_mut) != SUCCESS)
	{
		errorOutput(MUTEX_LOCK);
	}
    cout << msg << " ["<< put_time(localtime(&now), DATE)<< "]" << endl;
	if (pthread_mutex_unlock(&log_mut) != SUCCESS)
	{
		errorOutput(MUTEX_UNlOCK);
	}
}


/**
 * Performs the shuffle transition on the elements
 * @param args - a fictuous void* argument
 * @return a fictious void* return - returned the arg parameter.
 */
void* Shuffle (void* args)
{
    while (true)
    {
		if (pthread_mutex_lock(&tCountMut) != SUCCESS)
		{
			errorOutput(MUTEX_LOCK);
		}
        bool lastShuffle = (mapThreadCounter==0);
		if (pthread_mutex_unlock(&tCountMut) != SUCCESS)
		{
			errorOutput(MUTEX_UNlOCK);
		}
        for (auto it = pthreadsToContainer.begin(); it != pthreadsToContainer.end(); it++)
        {
			if (pthread_mutex_lock(&pthreadsToMutex[it->first]) != SUCCESS)
			{
				errorOutput(MUTEX_LOCK);
			}
            while (it->second.size() > 0)
            {
				sem_wait(&sem);
                k2Base* firstTo = it->second.back().first;
                v2Base* secondTo = it->second.back().second;
				shuffleContainers[firstTo].push_back(secondTo);
				if(autoDelete && shuffleContainers[firstTo].size() > 1)
				{
					delete firstTo;
				}
                it->second.pop_back();
            }
			if (pthread_mutex_unlock(&pthreadsToMutex[it->first]) != SUCCESS)
			{
				errorOutput(MUTEX_UNlOCK);
			}
		}
        if (lastShuffle)
        {
			if (sem_destroy(&sem) != SUCCESS)
            {
				errorOutput(SEM_DESTROY);
			}
			if (pthread_mutex_destroy(&tCountMut) != SUCCESS)
			{
				errorOutput(MUTEX_DESTROY);
			}
            for(auto mutIt = pthreadsToMutex.begin(); mutIt != pthreadsToMutex.end(); mutIt++)
            {
                if (pthread_mutex_destroy(&mutIt->second) != SUCCESS)
				{
					errorOutput(MUTEX_DESTROY);
				}
            }
			if (pthread_mutex_destroy(&mut_container) != SUCCESS)
			{
				errorOutput(MUTEX_DESTROY);
			}
            buildlog(SHUFFLE_TERMINATED);
            return args;
        }
    }
}


/**
 * Map wrapper - created in order to send to pthread create
 * @param args a void* argument as required by the pthread function.
 * @return void* - also requird by the pthread function
 */
void* MapWrapper(void* args)
{
    if (pthread_mutex_lock(&pthreadToContainerMutex) !=SUCCESS)
	{
		errorOutput(MUTEX_LOCK);
	}
	if (pthread_mutex_unlock(&pthreadToContainerMutex) !=SUCCESS)
	{
		errorOutput(MUTEX_UNlOCK);
	}

	while (true)
    {
        if (pthread_mutex_lock(&mut_container) != SUCCESS)
		{
			errorOutput(MUTEX_LOCK);
		}
        unsigned long i = chunkPointerMap;
        chunkPointerMap += CHUNK;
        if (pthread_mutex_unlock(&mut_container))
		{
			errorOutput(MUTEX_UNlOCK);
		}
        long chunkSize = INITIALIZE;
        if(global_item_vec.size() < i)
        {
			if (pthread_mutex_lock(&tCountMut) != SUCCESS)
            {
				errorOutput(MUTEX_UNlOCK);
			}
			mapThreadCounter--;
			if (mapThreadCounter == SUCCESS) {
				if (sem_post(&sem))
				{
					errorOutput(SEM_POST);
				}
			}
			if (pthread_mutex_unlock(&tCountMut) != SUCCESS)
			{
				errorOutput(MUTEX_UNlOCK);
			}
            buildlog(EXECMAP_TERMINATED);
            return args;
        }
        if(global_item_vec.size() < i + CHUNK)
        {
            chunkSize = (unsigned)global_item_vec.size() - i;
        }
        else
        {
            chunkSize = CHUNK;
        }
        for (unsigned long j = i; j < (i + chunkSize); j++)
        {
            const k1Base *key = global_item_vec.at(j).first;
            const v1Base *val = global_item_vec.at(j).second;
            mapReduceglobal->Map(key, val);
        }
    }
}


/**
 * The map execution and secion of the MapReduce algorithm
 * @param mapReduce Map Reduce object
 * @param multiThreadLevel the amount of threads to create
 */
void ExecMap (MapReduceBase& mapReduce, int multiThreadLevel)
{
	mapReduceglobal = &mapReduce;
	int mut1 = pthread_mutex_init(&mut_container, NULL);
	int mut2 = pthread_mutex_init(&pthreadToContainerMutex, NULL);
	int mut3 = pthread_mutex_init(&tCountMut, NULL);
	if (mut1 | mut2 || mut3)
    {
		errorOutput(MUTEX_INIT);
	}
	pthread_t threads[multiThreadLevel];
	for (int i = INITIALIZE; i < multiThreadLevel; i++)
    {
		if (pthread_create(&threads[i], NULL, &MapWrapper, nullptr) != SUCCESS)
        {
			errorOutput(CREATE_THREAD);
		}
		pthreadsToContainer[threads[i]] = vector<std::pair<k2Base *, v2Base *>>();
		buildlog(EXECMAP_CREATED);
		pthread_mutex_t cur_mutex;
		int curMut = pthread_mutex_init(&cur_mutex, NULL);
		if (curMut) { errorOutput(MUTEX_INIT); }
		pthreadsToMutex.insert(make_pair(threads[i], cur_mutex));
	}
	pthread_t shuffleThread;
	if (pthread_create(&shuffleThread, NULL, &Shuffle, NULL) != SUCCESS)
	{
		errorOutput(CREATE_THREAD);
	}
    buildlog(SHUFFLE_CREATED);
    for(unsigned int j = INITIALIZE; j < (unsigned int)multiThreadLevel; j++)
    {
        if (pthread_join(threads[j], NULL) != SUCCESS)
		{
			errorOutput(JOIN);
		}
    }
	if (sem_post(&sem))
	{
		errorOutput(SEM_POST);
	}
	if (pthread_join(shuffleThread, NULL) != SUCCESS)
	{
		errorOutput(JOIN);
	}
}


/**
 * The transition between a single k2, v2 pair - adding it to pthreads container
 * @param k2 the k2base
 * @param v2 the v2base
 */
void Emit2 (k2Base* k2, v2Base* v2)
{
	if (pthread_mutex_lock(&pthreadsToMutex[pthread_self()]) != SUCCESS)
	{
		errorOutput(MUTEX_LOCK);
	}
	pthreadsToContainer[pthread_self()].push_back(std::make_pair(k2, v2));
	if (pthread_mutex_unlock(&pthreadsToMutex[pthread_self()]) != SUCCESS)
	{
		errorOutput(MUTEX_UNlOCK);
	}
	if (sem_post(&sem) != SUCCESS)
	{
		errorOutput(SEM_POST);
	}
}


/**
 * Wrapper for reduce
 * @param args a fictuious void* argument to satiate the pthreads create
 * @return a fictuous return voidto satiate neccessary pthread functions
 */
void* ReduceWrapper(void* args)
{
    if (pthread_mutex_lock(&pthreadToContainerMutex) != SUCCESS)
	{
		errorOutput(MUTEX_LOCK);
	}
    if (pthread_mutex_unlock(&pthreadToContainerMutex) != SUCCESS)
	{
		errorOutput(MUTEX_UNlOCK);
	}
    while (true)
    {
		if (pthread_mutex_lock(&mut_container_reduce) != SUCCESS)
		{
			errorOutput(MUTEX_LOCK);
		}
        unsigned long index = chunkPointer;
        chunkPointer += CHUNK;
        if (pthread_mutex_unlock(&mut_container_reduce) != SUCCESS)
		{
			errorOutput(MUTEX_UNlOCK);
		}
        long chunkSize = INITIALIZE;
        if(shuffleContainers.size() <= index)
        {
            buildlog(REDUCE_MAP_TERMINATED);
            return args;
        }
        else if(shuffleContainers.size() < index + CHUNK)
        {
            chunkSize = (unsigned)shuffleContainers.size() - index;
        }
        else
        {
            chunkSize = CHUNK;
        }
        for (unsigned long i = index; i< index + chunkSize; i++)
        {
            auto itrBegin = shuffleContainers.begin();
            long curIndex = i;
            advance(itrBegin, curIndex);
            k2Base *key = itrBegin->first;
            V2_VEC val = itrBegin->second;
            mapReduceglobal->Reduce(key, val);
        }
    }
}


/**
 * Executes the reduce section for the MapReduce algorithm
 * @param mapReduce the mapreduce object
 * @param multiThreadLevel the amoount of threads in play
 */
void ExecReduce(int multiThreadLevel)
{
    int mut1 = pthread_mutex_init(&mut_container_reduce, NULL);
    int mut2 = pthread_mutex_init(&emit3Mutex, NULL);
	if (mut1 || mut2)
	{
		errorOutput(MUTEX_INIT);
	}
    pthread_t threads[multiThreadLevel];
    for (unsigned int i = INITIALIZE; i < (unsigned int)multiThreadLevel; i++)
    {
        if (pthread_create(&threads[i], NULL, &ReduceWrapper, nullptr) != SUCCESS)
		{
			errorOutput(CREATE_THREAD);
		}
        buildlog(REDUCE_MAP_CREATED);
    }
    for (int j = INITIALIZE; j < multiThreadLevel; j++)
    {
        if (pthread_join(threads[j], NULL) != SUCCESS)
		{
			errorOutput(JOIN);
		}
    }
    return;
}


/**
 * Produces final output for MapReduce flow by adding each pair to one container
 * @param k3 k3 value to be the first of the pair
 * @param v3 the v3 to be the second of the pair
 */
void Emit3 (k3Base* k3, v3Base* v3)
{
    OUT_ITEM pair = make_pair(k3,v3);
    if (pthread_mutex_lock(&emit3Mutex) != SUCCESS)
	{
		errorOutput(MUTEX_LOCK);
	}
    emit3Container.push_back(pair);
    if (pthread_mutex_unlock(&emit3Mutex) != SUCCESS)
	{
		errorOutput(MUTEX_UNlOCK);
	}
}


/**
 *Program main - executes the flow of the MapReduce
 * @param mapReduce the mapreduce object
 * @param itemsVec the input vector of k1,v1 items
 * @param multiThreadLevel the amount of threads in play
 * @param autoDeleteV2K2 the boolean indicator on which to decide if deletion is on the client
 * or user
 * @return the k3,v3 items
 */
OUT_ITEMS_VEC RunMapReduceFramework(MapReduceBase& mapReduce, IN_ITEMS_VEC& itemsVec, int multiThreadLevel,
                                    bool autoDeleteV2K2)
{
	autoDelete = autoDeleteV2K2;
	shuffleContainers = map<k2Base*, V2_VEC, bool (*)(k2Base*,k2Base*)>(
			[](k2Base* k1, k2Base* k2)->bool
            { return (*k1) < (*k2); });
    if (pthread_mutex_init(&globalMut, NULL) != SUCCESS)
	{
		errorOutput(MUTEX_INIT);
	}
    int o = dup(fileno(stdout));
    char buff[MAX_BUF];
    if (!getcwd( buff, MAX_BUF))
    {
        errorOutput(GETCWD);
    }
    string dir( buff );
    dir += MapReduceLog;
    const char * dir_c = dir.c_str();
    if (!freopen(dir_c, "a", stdout ))
    {
        errorOutput(FREOPEN);
    }
	cout << MAPREDUCEINITIALIZE << multiThreadLevel << THREADS << endl;
	chunkPointer = INITIALIZE;
    chunkPointerMap = INITIALIZE;
    global_item_vec = itemsVec;
    int mut1 = pthread_mutex_init(&mut, NULL);
    int mut2 = pthread_mutex_init(&log_mut, NULL);
	if (mut1 || mut2)
	{
		errorOutput(MUTEX_INIT);
	}
    struct timeval begin, end;
    gettimeofday(&begin, NULL);
    now = time(INITIALIZE);
    if (sem_init(&sem, INITIALIZE, INITIALIZE) != SUCCESS)
	{
		errorOutput(SEM_INIT);
	}
    mapThreadCounter = (unsigned int) multiThreadLevel;
    ExecMap(mapReduce, multiThreadLevel);
    gettimeofday(&end, NULL);
    cout << MAP_SHUFFLE_TIME << (end.tv_sec * NANOSECOND_CONVERSION + end.tv_usec)
                                       - (begin.tv_sec * NANOSECOND_CONVERSION + begin.tv_usec) <<
		 NANOSECONDS << endl;

    ExecReduce(multiThreadLevel);
    int destroy1 = pthread_mutex_destroy(&mut);
    int destroy2 = pthread_mutex_destroy(&mut_container_reduce);
    int destroy3 = pthread_mutex_destroy(&emit3Mutex);
	if (destroy1 || destroy2 || destroy3)
	{
		errorOutput(MUTEX_DESTROY);
	}
    gettimeofday(&end, NULL);
	cout << REDUCE_TIME << (end.tv_sec * NANOSECOND_CONVERSION + end.tv_usec)
							  - (begin.tv_sec * NANOSECOND_CONVERSION + begin.tv_usec) <<
		 NANOSECONDS << endl;
	cout << MAP_REDUCE_COMPLETE << endl;
	if (dup2(o,fileno(stdout)) == FAILURE)
	{
		errorOutput(DUP);
	}
	if (close(o) != SUCCESS)
	{
		errorOutput(CLOSE);
	}
	sort(emit3Container.begin(), emit3Container.end(), emitCompartor);
    if(autoDeleteV2K2)
    {
        auto itr = shuffleContainers.begin();
        while (itr != shuffleContainers.end())
		{
			for (unsigned int j = INITIALIZE; j < itr->second.size(); j ++)
            {
                delete itr->second.at(j);
            }
			if (itr->first != nullptr)
			{
				delete itr->first;
			}
			itr++;
        }
    }

    return emit3Container;
}