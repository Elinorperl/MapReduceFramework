#include <dirent.h>
#include <string>
#include <cstring>
#include <iostream>
#include "MapReduceClient.h"
#include "MapReduceFramework.h"

using namespace std;

#define INITALIZE 0
#define STARTINGPOINT 2
#define SUCCESS 0
#define USAGE "Usage: <substring to search> <folders, separated by space>"

/**
 * Extracts files to a vector of files from a directory
 * @param directory the directory gfrom which to extract files
 * @return a vector of files' names
 */
vector <string> extractFiles(string & directory)
{
	DIR *dir;
	struct dirent *dp;
	char * file_name;
	vector<string> files;
	dir = opendir(directory.c_str());
	if(dir != NULL){
		while ((dp=readdir(dir)) != NULL) {
			if ( !strcmp(dp->d_name, ".") || !strcmp(dp->d_name, "..") ) {}
			else
			{
				file_name = dp->d_name; // use it
				files.push_back(file_name);
			}
		}
		closedir(dir);
	}
	return files;
}

/**
 * A class which inherits from k1base,k2base, and k3base
 */
class file: public k1Base, public k2Base, public k3Base
{
private:
	 string fileName;
public:
	file(const string name): fileName(name) {}

	~file() override {}

	string get_name() const
	{
		return fileName;
	}

	bool operator<(const k1Base &other) const override
	{
		return fileName < (dynamic_cast<const file&>(other).fileName);
	}

	bool operator<(const k2Base &other) const override
	{
		return fileName < (dynamic_cast<const file&>(other).fileName);
	}


	bool operator<(const k3Base &other) const override
	{
		return fileName < (dynamic_cast<const file&>(other).fileName);

	}
};


/**
 * Values that inherit from v1Base and v2 Base
 */
class vValues :  public v1Base, public v2Base {
private:
	string name;
public:

	vValues(string other): name(other){}

	~vValues() {}

	string getName()
	{
		return name;
	}
};


/**
 * Values that inherit from v3base
 */
class fileAmount : public v3Base{
private:
	int value;
public:
	fileAmount(): value(INITALIZE){}

	~fileAmount() {}

	void incrementValue()
	{
		value++;
	}

	int getValue()
	{
		return value;
	}
};

/**
 * Client implementation for MapReduce
 */
class MapReduce: public MapReduceBase
{
public:
	MapReduce () {}

	~MapReduce() {}

    /**
     * Converts the values to the next "level" in order to "send" the key
     * to be searched for in the values.
     * @param key k1base input
     * @param val v1base value
     */
	void Map(const k1Base *const key, const v1Base *const val) const override
	{

		vValues *val9 = (vValues*)val;
		string dir_name = val9->getName();
		vector<string> files = extractFiles(dir_name);
		for(unsigned int i = INITALIZE; i<files.size(); i++)
		{
			file *key1 = (file*)key;
			if( files[i].find(key1->get_name()) != std::string::npos)
			{
				file *k2File = new file((string)files[i]);

				vValues *dir = (vValues*)val;
				vValues *v2Directory = new vValues(dir->getName());
				Emit2(k2File, v2Directory);
			}
		}
	}

    /**
     * given the second stage elements count the amount of time the key in found in a value
     * @param key the k2base key
     * @param vals the v2 base key
     */
	void Reduce(const k2Base *const key, const V2_VEC &vals) const override
	{
		fileAmount * sum  = new fileAmount();
		file *key2 = (file*)key;
		file *newKey = new file(key2->get_name());

		for(unsigned int i = INITALIZE; i < vals.size(); i++)
		{
			sum->incrementValue();
		}
		Emit3(newKey, sum);
	}
};

/**
 * Main function that executes the seach program
 * @param argc the amount of arguments
 * @param argv the file to be searched and the files to search within
 * @return
 */
int main(int argc, char *argv[])
{
	if (argc < STARTINGPOINT)
	{
		std::cerr << USAGE << std::endl;
		exit(SUCCESS);
	}
	MapReduce mapReduce;
	std::vector<IN_ITEM> pairs;
	for (int i = STARTINGPOINT; i < argc; i ++)
	{
		file *key1 = new file(argv[1]);
		vValues *value = new vValues(argv[i]);
		IN_ITEM pair = std::make_pair(key1, value);
		pairs.push_back(pair);
	}
	OUT_ITEMS_VEC output = RunMapReduceFramework(mapReduce, pairs, 4, true);
	for(unsigned int j = INITALIZE; j<output.size(); j++)
	{
		file *toPrint = (file*)output.at(j).first;
		fileAmount *amount = (fileAmount*)output.at(j).second;
		for(int i = INITALIZE; i < amount->getValue(); i++)
		{
			cout << toPrint->get_name() ;
			if (amount->getValue() - i)
			{
				cout << " ";
			}
		}
	}
	for (unsigned int i = STARTINGPOINT; i < (unsigned int)argc; i ++)
	{
		delete pairs.at(i-STARTINGPOINT).first;
		delete pairs.at(i-STARTINGPOINT).second;
	}
	for(OUT_ITEM &pair : output)
	{
		delete pair.first;
		delete pair.second;
	}
}